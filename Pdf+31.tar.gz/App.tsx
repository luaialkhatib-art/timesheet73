import './index.css';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  MapPin, Wifi, WifiOff, LogIn, LogOut, Users, Settings as SettingsIcon,
  FileBarChart, ClipboardList, CheckCircle2, XCircle, Clock, Download,
  RefreshCw, ShieldCheck, ShieldOff, Navigation, CalendarDays, UserPlus,
  Pencil, Trash2, Save, Stethoscope, AlarmClock, TimerOff, DoorOpen,
  Loader2, CloudUpload, CloudOff,
} from 'lucide-react';

/* ================= البيانات الأساسية: 31 موظفاً كما في الكشف ================= */
type Staff = { id: string; name: string; spec: string; pass: string; role: 'manager' | 'deputy' | 'teacher' };
const MANAGER_ID = '10510884';
const DEFAULT_STAFF: Staff[] = [
  { id: '30043214', name: 'Mahmoud Hamed Moh’d Al-shannik', spec: 'مدرس الأشغال اليدوية - التربية المهنية', pass: '123456', role: 'teacher' },
  { id: '10512150', name: 'محمد ابراهيم حجازي', spec: 'مدرس الأشغال اليدوية - التربية المهنية', pass: '123456', role: 'teacher' },
  { id: '30034197', name: 'Osama Husain Abdallah Shoubaki', spec: 'مدرس الحاسوب', pass: '123456', role: 'teacher' },
  { id: '10541315', name: 'معاذ ابراهيم جوارنه', spec: 'مدرس الحاسوب - حاسوب والكترونيات/المعلومات', pass: '123456', role: 'teacher' },
  { id: '10513454', name: 'أحمد خليل عطية عبيد', spec: 'مدرس اللغة الإنجليزية - اللغة الإنجليزية', pass: '123456', role: 'teacher' },
  { id: '10513796', name: 'معتز جمعه رجا سحيمات', spec: 'مدرس اللغة الإنجليزية - اللغة الإنجليزية', pass: '123456', role: 'teacher' },
  { id: '30040743', name: 'نادر ابراهيم حبسي', spec: 'مدرس اللغة الإنجليزية', pass: '123456', role: 'teacher' },
  { id: '10774141', name: 'عنان حسن يوسف', spec: 'مدرس اللغة الإنجليزية - اللغة الإنجليزية', pass: '123456', role: 'teacher' },
  { id: '30043221', name: 'Ahmad Mohammad Mustafa Rababa', spec: 'مدرس تربية إسلامية', pass: '123456', role: 'teacher' },
  { id: '10540399', name: 'اسماعيل خليل محمد', spec: 'مدرس تربية إسلامية - التربية الإسلامية', pass: '123456', role: 'teacher' },
  { id: '10778122', name: 'لؤي احمد عبد الله حسين', spec: 'مدرس تربية إسلامية', pass: '123456', role: 'teacher' },
  { id: '10510080', name: 'جهاد علي حسن أبو تربية', spec: 'مدرس رياضة - تربية', pass: '123456', role: 'teacher' },
  { id: '10775910', name: 'ابراهيم عوض سليمان جرادات', spec: 'مدرس رياضيات', pass: '123456', role: 'teacher' },
  { id: '10778090', name: 'أحمد محمد محمود', spec: 'مدرس رياضيات - رياضيات', pass: '123456', role: 'teacher' },
  { id: '10513032', name: 'محمد جابر محمود شخانبة', spec: 'مدرس رياضيات - الرياضيات', pass: '123456', role: 'teacher' },
  { id: '10774178', name: 'محمد صالح سالم', spec: 'مدرس رياضيات - رياضيات', pass: '123456', role: 'teacher' },
  { id: '10511687', name: 'معناك محمد سعيد جرار حمولة', spec: 'مدرس رياضيات - حاسوب وتكنولوجيا المعلومات', pass: '123456', role: 'teacher' },
  { id: '10524688', name: 'هاني عادل احمد', spec: 'مدرس علوم - الاحياء', pass: '123456', role: 'teacher' },
  { id: '10513499', name: 'طارق محمود حمد', spec: 'مدرس علوم - الفيزياء/تربية', pass: '123456', role: 'teacher' },
  { id: '10512759', name: 'عبد الكريم عبد الرحيم صالح الجماعي', spec: 'مدرس علوم - الفيزياء', pass: '123456', role: 'teacher' },
  { id: '10540832', name: 'احمد ناجي كميسي', spec: 'مدرس علوم - العلوم', pass: '123456', role: 'teacher' },
  { id: '10513388', name: 'لؤي احمد علي السيد', spec: 'مدرس علوم - الفيزياء', pass: '123456', role: 'teacher' },
  { id: '10520135', name: 'أحمد خضر المحمد', spec: 'مدرس مواد اجتماعية - المواد الاجتماعية', pass: '123456', role: 'teacher' },
  { id: '10511435', name: 'عاصم محمد عبد', spec: 'مدرس مواد اجتماعية - الجغرافيا', pass: '123456', role: 'teacher' },
  { id: '10510884', name: 'لؤي تيسير نمر الخطيب', spec: 'مدير مدرسة - اللغة العربية (المدير)', pass: 'Unrwa2026', role: 'manager' },
  { id: '10540082', name: 'شادي سعيد مشرف', spec: 'معلم لغة عربية - اللغة العربية', pass: '123456', role: 'teacher' },
  { id: '30034724', name: 'صهيب علي سالم عيادات', spec: 'معلم لغة عربية', pass: '123456', role: 'teacher' },
  { id: '30041068', name: 'علاء جلال انس', spec: 'معلم لغة عربية', pass: '123456', role: 'teacher' },
  { id: '10513658', name: 'عثمان محمد ذياب العبسي', spec: 'معلم لغة عربية - اللغة العربية', pass: '123456', role: 'teacher' },
  { id: '30040821', name: 'محمد عماد يوسف كساب', spec: 'معلم لغة عربية', pass: '123456', role: 'teacher' },
  { id: '10511588', name: 'فادي عبدالله سلمان ثابت', spec: 'نائب مدير مدرسة - تربية', pass: '123456', role: 'deputy' },
];

const STATUSES = ['حضور', 'غياب', 'مرضية', 'طارئة', 'تأخر', 'مبكر'] as const;
type Status = (typeof STATUSES)[number] | 'إنهاء دوام';

type AttValue = {
  teacherId: string; teacherName: string; date: string; status: string;
  time: string; lat?: number | null; lng?: number | null; distanceM?: number | null;
  source: 'teacher' | 'manager'; note?: string;
};
type Rec = { id: string; value: AttValue; updated_at?: string };

/* إعدادات مرقّمة بإصدار وطابع زمني — النسخة الأحدث دائماً هي المرجع */
type Settings = {
  locationVerificationEnabled: boolean;
  schoolLat: number; schoolLng: number; radiusM: number;
  version: number;
  updated_at: number;
};
const DEFAULT_SETTINGS: Settings = {
  locationVerificationEnabled: true,
  schoolLat: 32.5560, schoolLng: 35.8490, radiusM: 250,
  version: 0, updated_at: 0,
};

/* ================= واجهة السجلات السحابية ================= */
async function api(action: string, args: Record<string, unknown>) {
  const res = await fetch('actions', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action, args }),
  });
  let j: any = {};
  try { j = await res.json(); } catch { /* رد غير صالح */ }
  if (!res.ok || j.error) throw new Error(j.error || `HTTP ${res.status}`);
  return j.data;
}
const listAll = async (collection: string) => {
  const out: any[] = [];
  let cursor: string | undefined;
  for (let page = 0; page < 20; page++) {
    const data = await api('records.list', { collection, limit: 100, ...(cursor ? { cursor } : {}) });
    out.push(...(data.records || []));
    if (!data.next_cursor) break;
    cursor = data.next_cursor;
  }
  return out;
};
/* إعادة محاولة واحدة عند أعطال الشبكة العابرة — لا نعيد أخطاء الحصة أو مفاتيح عدم التكرار */
const withRetry = async <T,>(fn: () => Promise<T>): Promise<T> => {
  try { return await fn(); } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes('idempotency') || msg.includes('limit')) throw e;
    await new Promise((r) => setTimeout(r, 900));
    return fn();
  }
};

/* ================= أدوات ================= */
function distM(lat1: number, lng1: number, lat2: number, lng2: number) {
  const R = 6371000, toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(a)));
}
const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const nowTime = () => new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' });
const statusColor = (s: string) =>
  s === 'حضور' ? 'bg-emerald-500' : s === 'غياب' ? 'bg-rose-500' : s === 'مرضية' ? 'bg-sky-500'
  : s === 'طارئة' ? 'bg-violet-500' : s === 'تأخر' ? 'bg-amber-500' : s === 'مبكر' ? 'bg-teal-500' : 'bg-slate-500';
const statusIcon = (s: string) =>
  s === 'حضور' ? <CheckCircle2 size={13} /> : s === 'غياب' ? <XCircle size={13} /> : s === 'مرضية' ? <Stethoscope size={13} />
  : s === 'طارئة' ? <AlarmClock size={13} /> : s === 'تأخر' ? <Clock size={13} /> : s === 'مبكر' ? <DoorOpen size={13} /> : <TimerOff size={13} />;

function download(name: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a');
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/* ================= التطبيق ================= */
export default function App() {
  const [user, setUser] = useState<Staff | null>(null);
  const [loginId, setLoginId] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginErr, setLoginErr] = useState('');

  const [staff, setStaff] = useState<Staff[]>(DEFAULT_STAFF);
  const staffRecId = useRef<Record<string, string>>({});
  const [records, setRecords] = useState<Rec[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const settingsRecId = useRef<string | null>(null);
  /* مرجع دائم لأحدث إعدادات — يمنع أي إغلاق قديم (stale closure) في مسارات التسجيل غير المتزامنة */
  const settingsRef = useRef<Settings>(DEFAULT_SETTINGS);
  const settingsFetching = useRef(false);
  const [geoOk, setGeoOk] = useState(false);
  const [settingsSyncedAt, setSettingsSyncedAt] = useState('');
  const [settingsVersionSeen, setSettingsVersionSeen] = useState(0);
  const [settingsRefreshing, setSettingsRefreshing] = useState(false);
  useEffect(() => { settingsRef.current = settings; }, [settings]);

  const [date, setDate] = useState(todayISO());
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [queue, setQueue] = useState<{ key: string; value: AttValue; existingId?: string }[]>([]);
  const [lastSync, setLastSync] = useState('');
  const [marking, setMarking] = useState<string | null>(null);
  const [seedBusy, setSeedBusy] = useState(false);
  const [seedResult, setSeedResult] = useState<{ saved: number; remaining: number; error: string | null; reloadError: string | null } | null>(null);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const [geoMsg, setGeoMsg] = useState('');
  const [geoPos, setGeoPos] = useState<{ lat: number; lng: number; d: number } | null>(null);
  const [tab, setTab] = useState<'quick' | 'report' | 'staff' | 'settings'>('quick');
  const [repTeacher, setRepTeacher] = useState('ALL');
  const [repFrom, setRepFrom] = useState(() => todayISO().slice(0, 7));
  const [repTo, setRepTo] = useState(() => todayISO().slice(0, 7));
  const [form, setForm] = useState({ id: '', name: '', spec: '', pass: '123456' });
  const [editingId, setEditingId] = useState<string | null>(null);
  const staffFormRef = useRef<HTMLDivElement | null>(null);
  const staffNameRef = useRef<HTMLInputElement | null>(null);
  const toastTimer = useRef<any>(null);
  const flushing = useRef(false);
  const seeding = useRef(false);
  const queueRef = useRef(queue);
  useEffect(() => { queueRef.current = queue; }, [queue]);

  const showToast = useCallback((msg: string, ok = true) => {
    setToast({ msg, ok });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3400);
  }, []);

  const isManager = user?.role === 'manager';
  const TEACHERS_ONLY = useMemo(
    () => staff.filter((t) => String(t.id) !== MANAGER_ID),
    [staff],
  );

  /* ---------- تطبيق صفوف الهيئة السحابية فوق القائمة الافتراضية ---------- */
  const applyStaffRows = useCallback((rows: any[]) => {
    setStaff(() => {
      const map = new Map(DEFAULT_STAFF.map((s) => [String(s.id), s]));
      for (const r of rows) {
        const v: any = r.value;
        if (!v || v.tid == null) continue;
        staffRecId.current[String(v.tid)] = r.id;
        if (v.deleted) map.delete(String(v.tid));
        else map.set(String(v.tid), { id: String(v.tid), name: v.name, spec: v.spec, pass: v.pass || '123456', role: v.role || 'teacher' });
      }
      return Array.from(map.values());
    });
  }, []);

  const reloadStaff = useCallback(async () => {
    const rows = await listAll('teachers_store');
    applyStaffRows(rows);
    return rows;
  }, [applyStaffRows]);

  /* ---------- الإعدادات: جلب مباشر من السحابة واختيار الأحدث زمنياً ----------
     1) طلب records.list مباشرة من السحابة (لا من أي حالة محفوظة).
     2) اختيار السجل ذي أكبر updated_at — أحدث قرار للمدير يفوز دائماً.
     3) تحديث المرجع والحالة فوراً، وحذف أي سجلات إعدادات زائدة (الأفضل جهداً)
        حتى لا يبقى سجل قديم يلتبس على أي هاتف. */
  const fetchSettingsFromCloud = useCallback(async (): Promise<Settings> => {
    if (settingsFetching.current) return settingsRef.current;
    settingsFetching.current = true;
    try {
      const rows = await listAll('settings');
      if (rows.length) {
        let best = rows[0];
        let bestTs = Number((best.value as any)?.updated_at) || 0;
        for (const r of rows) {
          const ts = Number((r.value as any)?.updated_at) || 0;
          if (ts >= bestTs) { best = r; bestTs = ts; }
        }
        const next: Settings = { ...DEFAULT_SETTINGS, ...(best.value as object) };
        settingsRecId.current = best.id;
        settingsRef.current = next;
        setSettings(next);
        setSettingsVersionSeen(next.version || 0);
        setSettingsSyncedAt(new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        /* تنظيف النسخ الزائدة حتى يبقى سجل إعدادات واحد فقط هو الأحدث */
        for (const r of rows) {
          if (r.id !== best.id) {
            try { await api('records.delete', { collection: 'settings', id: r.id }); } catch { /* أفضل جهد */ }
          }
        }
        return next;
      }
      return settingsRef.current;
    } finally {
      settingsFetching.current = false;
    }
  }, []);
  const reloadSettingsCloud = fetchSettingsFromCloud;

  /* جلب أحدث إعدادات من السحابة الآن — يُستدعى قبل كل محاولة تسجيل حتى لا تُستخدم قيمة مخزّنة قديمة.
     عند تعذّر الاتصال نعود للقيمة المحلية الأخيرة (المرجع) دون إيقاف التسجيل. */
  const fetchFreshSettings = useCallback(async (): Promise<Settings> => {
    try {
      return await fetchSettingsFromCloud();
    } catch { /* لا اتصال — نستخدم آخر إعدادات معروفة محلياً */ }
    return settingsRef.current;
  }, [fetchSettingsFromCloud]);

  /* القيمة الفعّالة للتحقق الجغرافي دائماً من المرجع الحديث — لا من حالة قديمة داخل إغلاق */
  const getEffectiveLocationEnabled = useCallback(() => settingsRef.current.locationVerificationEnabled, []);

  /* ---------- تحميل سجلات الحضور مع إزالة التكرار (سجل واحد لكل معلم/يوم) ---------- */
  const reloadRecords = useCallback(async () => {
    const rows = await listAll('attendance');
    const mapped: Rec[] = rows.map((r: any) => ({ id: r.id, value: r.value as AttValue, updated_at: r.updated_at }));
    const byKey = new Map<string, Rec>();
    for (const r of mapped) {
      const k = `${r.value.teacherId}|${r.value.date}`;
      const prev = byKey.get(k);
      if (!prev || (r.updated_at || '') >= (prev.updated_at || '')) byKey.set(k, r);
    }
    const cloud = Array.from(byKey.values());
    setRecords((prev) => {
      /* الاحتفاظ بالسجلات المحلية المؤقتة التي لم تصل السحابة بعد حتى لا تومض الواجهة */
      const pending = prev.filter((r) => r.id.startsWith('tmp-') &&
        !cloud.some((c) => String(c.value.teacherId) === String(r.value.teacherId) && c.value.date === r.value.date));
      return [...cloud, ...pending];
    });
    setLastSync(new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  }, []);

  /* ---------- زرع قائمة الـ31 في السحابة عند أول تشغيل (سحابة فارغة) ---------- */
  const pushDefaultStaff = useCallback(async () => {
    if (seeding.current) return;
    seeding.current = true;
    const rows = [...DEFAULT_STAFF];
    setSeedBusy(true);
    let saved = 0;
    let error: string | null = null;
    try {
      for (const s of rows) {
        const created = await api('records.create', {
          collection: 'teachers_store',
          value: { tid: String(s.id), name: s.name, spec: s.spec, pass: s.pass, role: s.role },
          idempotency_key: `staff-seed-${s.id}`,
        });
        staffRecId.current[String(s.id)] = created.id;
        saved += 1;
      }
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
    }
    let reloadError: string | null = null;
    try { await reloadStaff(); } catch (e) { reloadError = e instanceof Error ? e.message : String(e); }
    setSeedResult({ saved, remaining: rows.length - saved, error, reloadError });
    setSeedBusy(false);
  }, [reloadStaff]);

  /* ---------- التحميل الأولي: كل مجموعة مستقلة حتى لا يمنع فشل إحداها الباقي ---------- */
  const loadAll = useCallback(async () => {
    try { await reloadRecords(); } catch { /* المعاينة دون خادم — تبقى الحالة المحلية */ }
    try { await fetchSettingsFromCloud(); } catch { /* إعدادات افتراضية */ }
    try {
      const rows = await reloadStaff();
      if (rows.length === 0) void pushDefaultStaff();
    } catch { /* قائمة DEFAULT_STAFF المحلية تكفي للدخول دون اتصال */ }
  }, [reloadRecords, fetchSettingsFromCloud, reloadStaff, pushDefaultStaff]);

  useEffect(() => { loadAll(); }, [loadAll]);

  /* ---------- مزامنة سحابية شاملة كل 4 ثوانٍ أثناء تسجيل الدخول ----------
     تنعكس تسجيلات المعلم من أي هاتف لدى المدير، ويصل مفتاح المدير الجغرافي لكل الهواتف */
  const syncCloud = useCallback(async () => {
    const jobs: Promise<unknown>[] = [reloadRecords(), reloadStaff()];
    if (tab !== 'settings') jobs.push(fetchSettingsFromCloud());
    await Promise.allSettled(jobs);
  }, [reloadRecords, reloadStaff, fetchSettingsFromCloud, tab]);

  useEffect(() => {
    if (!user) return;
    void syncCloud();
    const iv = setInterval(() => { void syncCloud(); }, 4000);
    return () => clearInterval(iv);
  }, [user, syncCloud]);

  /* استطلاع مخصّص للإعدادات كل 3 ثوانٍ لأي مستخدم (معلم أو مدير) + عند عودة التركيز والاتصال:
     عندما يعطّل المدير التحقق الجغرافي من هاتفه ينعكس ذلك على هاتف المعلم خلال 3 ثوانٍ دون إعادة تشغيل */
  useEffect(() => {
    if (!user) return;
    const iv = setInterval(() => { void fetchFreshSettings(); }, 3000);
    const onFocus = () => { void fetchFreshSettings(); };
    const onOnline = () => { void fetchFreshSettings(); };
    window.addEventListener('focus', onFocus);
    window.addEventListener('online', onOnline);
    return () => {
      clearInterval(iv);
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('online', onOnline);
    };
  }, [user, fetchFreshSettings]);

  /* ---------- حالة الاتصال (للعرض فقط — لا نعتمد عليها لقرار الحفظ) ---------- */
  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  /* ---------- الحفظ السحابي أولاً دائماً، بمفتاح عدم تكرار ثابت لكل معلم/يوم ---------- */
  const persistRecord = useCallback(async (value: AttValue, existingId?: string): Promise<string> => {
    if (existingId) {
      await withRetry(() => api('records.replace', { collection: 'attendance', id: existingId, value }));
      return existingId;
    }
    try {
      const created = await withRetry(() => api('records.create', {
        collection: 'attendance', value,
        idempotency_key: `att-${value.teacherId}-${value.date}`,
      }));
      return created.id as string;
    } catch (e) {
      /* السجل موجود سحابياً من محاولة سابقة ضاع ردّها: نعيد تحميله ونستبدله بدل إنشاء مكرر */
      if (e instanceof Error && e.message.includes('idempotency key reused')) {
        const rows = await listAll('attendance');
        const found = rows.find((r: any) => String(r.value.teacherId) === String(value.teacherId) && r.value.date === value.date);
        if (found) {
          await api('records.replace', { collection: 'attendance', id: found.id, value });
          return found.id as string;
        }
      }
      throw e;
    }
  }, []);

  const saveAttendance = useCallback(async (value: AttValue, existing?: Rec): Promise<boolean> => {
    /* تحديث متفائل فوري وظيفياً: تنعكس الحالة على الشاشة قبل أي رد شبكي */
    setRecords((prev) => {
      const idx = prev.findIndex((r) => String(r.value.teacherId) === String(value.teacherId) && r.value.date === value.date);
      if (idx >= 0) { const cp = [...prev]; cp[idx] = { ...cp[idx], value }; return cp; }
      return [...prev, { id: `tmp-${value.teacherId}-${value.date}`, value }];
    });
    try {
      /* نحاول السحابة أولاً دائماً — حتى لو أبلغ المتصفح أنه غير متصل */
      const realId = await persistRecord(value, existing && !existing.id.startsWith('tmp-') ? existing.id : undefined);
      setRecords((prev) => {
        const idx = prev.findIndex((r) => String(r.value.teacherId) === String(value.teacherId) && r.value.date === value.date);
        if (idx >= 0) { const cp = [...prev]; cp[idx] = { id: realId, value }; return cp; }
        return [...prev, { id: realId, value }];
      });
      /* مزامنة فورية بعد الحفظ حتى ترى بقية الأجهزة السجل دون انتظار الدورة التالية */
      reloadRecords().catch(() => {});
      return true;
    } catch {
      /* بديل عدم الاتصال: قائمة انتظار محلية تُرفع تلقائياً عند توفر أي اتصال */
      setQueue((q) => [
        ...q.filter((x) => !(String(x.value.teacherId) === String(value.teacherId) && x.value.date === value.date)),
        { key: `${value.teacherId}|${value.date}`, value, existingId: existing && !existing.id.startsWith('tmp-') ? existing.id : undefined },
      ]);
      return false;
    }
  }, [persistRecord, reloadRecords]);

  /* ---------- رفع قائمة الانتظار: يعمل دورياً ولا ينتظر حدث online فقط ---------- */
  const flushQueue = useCallback(async () => {
    if (flushing.current || queueRef.current.length === 0) return;
    flushing.current = true;
    let saved = 0;
    try {
      for (const item of [...queueRef.current]) {
        try {
          await persistRecord(item.value, item.existingId);
          saved++;
          setQueue((q) => q.filter((x) => x.key !== item.key));
        } catch { break; }
      }
    } finally { flushing.current = false; }
    if (saved > 0) {
      showToast(`تمت مزامنة ${saved} سجل مع السحابة — أصبح ظاهراً على جميع الأجهزة`);
      reloadRecords().catch(() => {});
    }
  }, [persistRecord, reloadRecords, showToast]);

  useEffect(() => {
    if (queue.length === 0) return;
    void flushQueue();
    const iv = setInterval(() => { void flushQueue(); }, 8000);
    return () => clearInterval(iv);
  }, [queue.length, flushQueue]);

  useEffect(() => {
    const onOnline = () => { void flushQueue(); };
    window.addEventListener('online', onOnline);
    return () => window.removeEventListener('online', onOnline);
  }, [flushQueue]);

  /* ---------- التحقق الجغرافي: محاولة عالية الدقة ثم عادية ---------- */
  const getPosition = useCallback((high: boolean) => new Promise<{ lat: number; lng: number }>((resolve, reject) => {
    if (!('geolocation' in navigator)) { reject(new Error('المتصفح لا يدعم تحديد الموقع')); return; }
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => reject(new Error('تعذّر الحصول على موقعك — فعّل GPS واسمح بالوصول للموقع من إعدادات المتصفح')),
      { enableHighAccuracy: high, timeout: high ? 12000 : 20000, maximumAge: 5000 },
    );
  }), []);

  const checkGeo = useCallback(async (): Promise<{ lat: number; lng: number; d: number }> => {
    let coords: { lat: number; lng: number };
    try { coords = await getPosition(true); } catch { coords = await getPosition(false); }
    const s = settingsRef.current; // أحدث إحداثيات ونصف قطر — لا قيمة قديمة من إغلاق سابق
    const d = distM(coords.lat, coords.lng, s.schoolLat, s.schoolLng);
    setGeoPos({ lat: coords.lat, lng: coords.lng, d });
    return { lat: coords.lat, lng: coords.lng, d };
  }, [getPosition]);

  /* بوّابة التحقق الجغرافي — الترتيب الإلزامي قبل أي إجراء حضور:
     1) جلب أحدث إعدادات مباشرة من السحابة (أكبر updated_at) — قرار المدير الأحدث يصل قبل أي فحص.
     2) إن كان التحقق معطّلاً بقرار المدير: السماح فوراً دون لمس GPS إطلاقاً.
     3) فقط عند التفعيل نطلب الموقع ونقارن بالنطاق. المدير معفى دائماً. */
  const guardGeo = useCallback(async (): Promise<{ lat: number; lng: number; d: number } | null | undefined> => {
    const fresh = await fetchFreshSettings();
    if (!getEffectiveLocationEnabled() || isManager) {
      setGeoOk(true);
      if (!isManager) setGeoMsg('التحقق من الموقع الجغرافي معطّل بقرار المدير — يمكن التسجيل من أي مكان');
      return undefined;
    }
    setGeoMsg('جارٍ تحديد موقعك بدقة…');
    try {
      const pos = await checkGeo();
      if (pos.d <= fresh.radiusM) {
        setGeoOk(true);
        setGeoMsg(`أنت داخل نطاق المدرسة — المسافة ${pos.d} م من أصل ${fresh.radiusM} م`);
        return pos;
      }
      setGeoOk(false);
      setGeoMsg(`أنت خارج نطاق المدرسة — المسافة ${pos.d} م والحد المسموح ${fresh.radiusM} م`);
      showToast(`لا يمكن التسجيل: أنت خارج النطاق الجغرافي للمدرسة (${pos.d} م)`, false);
      return null;
    } catch (e: any) {
      setGeoOk(false);
      setGeoMsg(e.message);
      showToast(e.message, false);
      return null;
    }
  }, [fetchFreshSettings, getEffectiveLocationEnabled, isManager, checkGeo, showToast]);

  /* ---------- إجراءات المعلم ---------- */
  const findRec = useCallback((tid: string, d: string) =>
    records.find((r) => String(r.value.teacherId) === String(tid) && r.value.date === d), [records]);

  const markWith = async (status: Status, note?: string, okMsg?: string) => {
    if (!user || marking) return;
    setMarking(status);
    try {
      const pos = await guardGeo();
      if (pos === null) return;
      const ok = await saveAttendance({
        teacherId: String(user.id), teacherName: user.name, date, status,
        time: nowTime(), lat: pos?.lat ?? null, lng: pos?.lng ?? null,
        distanceM: pos?.d ?? null, source: 'teacher', ...(note ? { note } : {}),
      }, findRec(user.id, date));
      if (ok) showToast(`${okMsg || `تم تسجيل «${status}»`} وحُفظ في السحابة — سيظهر لدى المدير فوراً`);
      else showToast('حُفظ على هذا الجهاز وسيُرفع للسحابة تلقائياً عند توفر الاتصال', false);
    } finally { setMarking(null); }
  };
  const teacherMark = (status: Status) => markWith(status);
  const teacherEndDay = () => markWith('إنهاء دوام', undefined, 'تم إنهاء اليوم');
  const teacherEarlyDeparture = () => markWith('مبكر', 'مغادرة مبكرة', 'تم تسجيل المغادرة المبكرة');

  /* زر المعلم: فرض جلب الإعدادات من السحابة الآن وإظهار النتيجة */
  const forceRefreshSettings = async () => {
    setSettingsRefreshing(true);
    try {
      const fresh = await fetchSettingsFromCloud();
      setGeoMsg('');
      showToast(fresh.locationVerificationEnabled
        ? 'تم التحديث: التحقق من الموقع مفعّل بقرار المدير — يجب أن تكون داخل المدرسة'
        : 'تم التحديث: التحقق من الموقع معطّل بقرار المدير — يمكنك التسجيل من أي مكان');
    } catch {
      showToast('تعذّر الاتصال بالسحابة الآن — تُستخدم آخر إعدادات معروفة على هذا الجهاز', false);
    } finally { setSettingsRefreshing(false); }
  };

  /* ---------- إجراء المدير السريع (تحديث فوري + حفظ سحابي بالخلفية) ---------- */
  const handleManagerSetStatus = (tid: string, status: string) => {
    const t = TEACHERS_ONLY.find((x) => String(x.id) === String(tid));
    if (!t) return;
    const value: AttValue = {
      teacherId: String(tid), teacherName: t.name, date, status,
      time: nowTime(), lat: null, lng: null, distanceM: null, source: 'manager',
    };
    const existing = records.find((r) => String(r.value.teacherId) === String(tid) && r.value.date === date);
    showToast(`تم تسجيل «${status}» للمعلم ${t.name}`);
    void saveAttendance(value, existing).then((ok) => {
      if (!ok) showToast('حُفظ محلياً وسيُزامَن مع السحابة تلقائياً', false);
    });
  };

  /* ---------- الإعدادات: كل حفظ يزيد الإصدار ويحدّث الطابع الزمني ---------- */
  const saveSettings = async (next: Settings, silent = false) => {
    const stamped: Settings = {
      ...next,
      version: (settingsRef.current.version || 0) + 1,
      updated_at: Date.now(),
    };
    settingsRef.current = stamped; // تحديث فوري للمرجع حتى لا يقرأ أي مسار قيمة قديمة
    setSettings(stamped);
    setSettingsVersionSeen(stamped.version);
    try {
      if (settingsRecId.current) await api('records.replace', { collection: 'settings', id: settingsRecId.current, value: stamped });
      else {
        const c = await api('records.create', { collection: 'settings', value: stamped, idempotency_key: 'school-settings-main' });
        settingsRecId.current = c.id;
      }
      if (!silent) showToast('تم حفظ الإعدادات في السحابة — ستسري على جميع الهواتف خلال 3 ثوانٍ');
      return stamped;
    } catch {
      if (!silent) showToast('حُفظت الإعدادات على هذا الجهاز وستُزامَن عند توفر الاتصال', false);
      return stamped;
    }
  };

  /* مفتاح المدير: تبديل التحقق الجغرافي مع إصدار جديد وطابع زمني حديث */
  const toggleLocationVerification = async () => {
    const wasEnabled = settingsRef.current.locationVerificationEnabled;
    const next = await saveSettings(
      { ...settingsRef.current, locationVerificationEnabled: !wasEnabled },
      true,
    );
    showToast(next.locationVerificationEnabled
      ? 'تم تفعيل التحقق من الموقع — سيصل لكل المعلمين خلال 3 ثواني'
      : 'تم تعطيل التحقق من الموقع — سيصل لكل المعلمين خلال 3 ثواني');
  };

  /* ---------- إدارة المعلمين (CRUD على teachers_store) ---------- */
  const startEditTeacher = (t: Staff) => {
    setEditingId(String(t.id));
    setForm({ id: String(t.id), name: t.name, spec: t.spec, pass: t.pass || '123456' });
    showToast(`وضع التعديل: ${t.name} — عدّل البيانات في النموذج بالأعلى ثم اضغط «حفظ التعديلات»`);
    requestAnimationFrame(() => {
      staffFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      window.setTimeout(() => staffNameRef.current?.focus({ preventScroll: true }), 400);
    });
  };
  const cancelEdit = () => {
    setEditingId(null);
    setForm({ id: '', name: '', spec: '', pass: '123456' });
  };
  const saveStaffMember = async () => {
    const newId = form.id.trim();
    const newName = form.name.trim();
    if (!newId || !newName) { showToast('أدخل الرقم الوظيفي والاسم الكامل', false); return; }
    const isEditing = !!editingId;
    const existing = isEditing ? staff.find((s) => String(s.id) === String(editingId)) : undefined;
    if (!isEditing && staff.some((s) => String(s.id) === newId)) {
      showToast('هذا الرقم الوظيفي مسجّل مسبقاً — استخدم زر «تعديل» بجانب اسم المعلم', false);
      return;
    }
    if (isEditing && newId !== String(editingId) && staff.some((s) => String(s.id) === newId)) {
      showToast('الرقم الوظيفي الجديد مستخدم من قبل معلم آخر', false);
      return;
    }
    const member: Staff = {
      id: newId, name: newName, spec: form.spec.trim(),
      pass: form.pass || '123456',
      role: newId === MANAGER_ID ? 'manager' : (existing?.role ?? 'teacher'),
    };
    setStaff((prev) => {
      if (isEditing) return prev.map((s) => (String(s.id) === String(editingId) ? member : s));
      return [...prev, member];
    });
    try {
      const v = { tid: member.id, name: member.name, spec: member.spec, pass: member.pass, role: member.role };
      const oldRecId = isEditing ? staffRecId.current[String(editingId)] : undefined;
      if (isEditing && newId === String(editingId) && oldRecId) {
        await api('records.replace', { collection: 'teachers_store', id: oldRecId, value: v });
      } else {
        const c = await api('records.create', { collection: 'teachers_store', value: v, idempotency_key: `staff-${member.id}-${Date.now()}` });
        staffRecId.current[member.id] = c.id;
        if (isEditing && oldRecId && newId !== String(editingId)) {
          await api('records.replace', { collection: 'teachers_store', id: oldRecId, value: { tid: String(editingId), deleted: true } });
          delete staffRecId.current[String(editingId)];
        }
      }
      reloadStaff().catch(() => {});
    } catch { showToast('حُفظ التعديل على هذا الجهاز وسيُزامَن لاحقاً', false); }
    setForm({ id: '', name: '', spec: '', pass: '123456' });
    setEditingId(null);
    showToast(isEditing ? `تم حفظ تعديلات «${member.name}» بنجاح` : 'تمت إضافة المعلم بنجاح');
  };
  const deleteStaffMember = async (tid: string) => {
    setStaff((prev) => prev.filter((s) => String(s.id) !== String(tid)));
    try {
      const v = { tid: String(tid), deleted: true };
      if (staffRecId.current[String(tid)]) await api('records.replace', { collection: 'teachers_store', id: staffRecId.current[String(tid)], value: v });
      else {
        const c = await api('records.create', { collection: 'teachers_store', value: v, idempotency_key: `staff-del-${tid}` });
        staffRecId.current[String(tid)] = c.id;
      }
      reloadStaff().catch(() => {});
    } catch { /* محلياً */ }
    showToast('تم حذف المعلم');
  };

  /* ---------- الدخول ---------- */
  const doLogin = () => {
    const found = staff.find((s) => String(s.id) === String(loginId).trim());
    if (!found) { setLoginErr('الرقم الوظيفي غير موجود في كشف الموظفين'); return; }
    if (found.pass !== loginPass) { setLoginErr('كلمة المرور غير صحيحة'); return; }
    setLoginErr('');
    setUser(found);
    showToast(`مرحباً ${found.name}`);
    void fetchFreshSettings();
    void syncCloud();
  };

  /* ---------- التقارير والتصدير ---------- */
  const reportRows = useMemo(() => {
    const from = `${repFrom}-01`, to = `${repTo}-31`;
    return records.filter((r) =>
      r.value.date >= from && r.value.date <= to &&
      (repTeacher === 'ALL' || String(r.value.teacherId) === repTeacher));
  }, [records, repFrom, repTo, repTeacher]);

  const reportSummary = useMemo(() => {
    const m = new Map<string, Record<string, number>>();
    for (const r of reportRows) {
      const cur = m.get(r.value.teacherId) || { name: r.value.teacherName as any };
      (cur as any)[r.value.status] = ((cur as any)[r.value.status] || 0) + 1;
      m.set(r.value.teacherId, cur as any);
    }
    return Array.from(m.entries());
  }, [reportRows]);

  const exportCSV = () => {
    const head = 'الرقم الوظيفي,الاسم,التاريخ,الحالة,الوقت,المسافة (م),المصدر\n';
    const body = reportRows.map((r) => [r.value.teacherId, `"${r.value.teacherName}"`, r.value.date, r.value.status, r.value.time, r.value.distanceM ?? '', r.value.source === 'manager' ? 'المدير' : 'المعلم'].join(',')).join('\n');
    download(`attendance-${repFrom}_${repTo}.csv`, '﻿' + head + body, 'text/csv;charset=utf-8');
    showToast('تم تصدير ملف CSV');
  };
  const exportExcelHTML = (ext: 'xls' | 'html') => {
    const rows = reportRows.map((r) =>
      `<tr><td>${r.value.teacherId}</td><td>${r.value.teacherName}</td><td>${r.value.date}</td><td>${r.value.status}</td><td>${r.value.time}</td><td>${r.value.distanceM ?? ''}</td></tr>`).join('');
    const html = `<html dir="rtl" lang="ar"><head><meta charset="utf-8"></head><body><h2>مدرسة ذكور مدينة إربد الإعدادية الثانية — كشف الحضور ${repFrom} إلى ${repTo}</h2><table border="1"><tr><th>الرقم الوظيفي</th><th>الاسم</th><th>التاريخ</th><th>الحالة</th><th>الوقت</th><th>المسافة (م)</th></tr>${rows}</table></body></html>`;
    download(`attendance-${repFrom}_${repTo}.${ext}`, html, ext === 'xls' ? 'application/vnd.ms-excel' : 'text/html;charset=utf-8');
    showToast(ext === 'xls' ? 'تم تصدير ملف Excel' : 'تم تصدير ملف HTML');
  };

  const dayStats = useMemo(() => {
    const day = records.filter((r) => r.value.date === date);
    return {
      present: day.filter((r) => r.value.status === 'حضور').length,
      absent: day.filter((r) => r.value.status === 'غياب').length,
      marked: day.length,
      total: TEACHERS_ONLY.length,
    };
  }, [records, date, TEACHERS_ONLY]);

  const myToday = user ? findRec(user.id, date) : undefined;
  const myPending = !!myToday && myToday.id.startsWith('tmp-');

  /* ================= الواجهة ================= */
  return (
    <div
      data-safe-area-inset-root
      dir="rtl"
      style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', minHeight: '100dvh', background: 'var(--surface)' }}
      className="w-full overflow-x-clip"
    >
      {/* الترويسة */}
      <header
        data-safe-area-sticky-top
        style={{ top: 'var(--safe-area-inset-top)' }}
        className="sticky z-40 grad-bg text-white shadow-lg"
      >
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-sm font-bold flex-wrap">
            {isOnline
              ? <span className="flex items-center gap-1 bg-white/15 rounded-full px-3 py-1"><Wifi size={15} /> متصل</span>
              : <span className="flex items-center gap-1 bg-rose-500/80 rounded-full px-3 py-1"><WifiOff size={15} /> غير متصل — وضع عدم الاتصال</span>}
            {queue.length > 0 && <span className="bg-amber-400 text-amber-950 rounded-full px-3 py-1 pulse-dot flex items-center gap-1"><CloudUpload size={14} /> بانتظار المزامنة: {queue.length}</span>}
            {lastSync && <span className="bg-white/10 rounded-full px-3 py-1 text-xs">آخر مزامنة سحابية: {lastSync}</span>}
          </div>
          <div className="ms-auto flex items-center gap-2">
            <label className="text-xs opacity-90 flex items-center gap-1"><CalendarDays size={14} /> التاريخ</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="rounded-lg px-2 py-1 text-sm text-slate-800 bg-white touch-manipulation" />
            {user && (
              <button type="button" onClick={() => setUser(null)} className="flex items-center gap-1 bg-white/15 hover:bg-white/25 rounded-full px-3 py-1 text-sm font-bold touch-manipulation">
                <LogOut size={15} /> خروج
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-10">
        {/* العنوان الرئيسي */}
        <section className="text-center pt-8 pb-2 anim-up">
          <p className="text-xs font-bold tracking-widest" style={{ color: 'var(--ink-soft)' }}>رمز المدرسة 1000596 · نظام الحضور والغياب الذكي</p>
          <h1 className="font-cairo font-black grad-text leading-tight" style={{ fontSize: 'clamp(26px, 7vw, 40px)' }}>
            مدرسة ذكور مدينة إربد الإعدادية الثانية
          </h1>
          <p className="mt-1 text-sm font-bold" style={{ color: 'var(--ink-soft)' }}>
            تسجيل الحضور ضمن النطاق الجغرافي للمدرسة — متزامن سحابياً بين جميع الهواتف ويعمل حتى دون اتصال
          </p>
        </section>

        {!isOnline && (
          <div className="mt-3 rounded-2xl bg-slate-800 text-white px-4 py-3 font-bold text-center flex items-center justify-center gap-2">
            <WifiOff size={18} /> أنت غير متصل بالإنترنت — يمكنك تسجيل الدخول والتسجيل، وستُزامَن البيانات تلقائياً عند عودة الاتصال
          </div>
        )}

        {!user ? (
          /* ---------- شاشة الدخول ---------- */
          <section className="card-premium max-w-lg mx-auto mt-8 p-6 anim-up">
            <h2 className="font-cairo text-2xl font-extrabold flex items-center gap-2 mb-1"><LogIn className="text-blue-600" /> تسجيل الدخول</h2>
            <p className="text-sm mb-5" style={{ color: 'var(--ink-soft)' }}>أدخل رقمك الوظيفي وكلمة المرور للدخول إلى النظام. يعمل الدخول دون اتصال أيضاً.</p>
            <form onSubmit={(e) => { e.preventDefault(); doLogin(); }}>
              <label className="block text-sm font-bold mb-1" htmlFor="login-job-number">الرقم الوظيفي</label>
              <input id="login-job-number" type="text" inputMode="numeric" autoComplete="username"
                required autoFocus placeholder="مثال: 10510884"
                value={loginId} onChange={(e) => setLoginId(e.target.value)}
                className="w-full rounded-xl border px-3 py-2.5 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
              <p className="text-xs mt-1.5 mb-4" style={{ color: 'var(--ink-soft)' }}>أدخل الرقم الوظيفي كما في كشف EMIS</p>
              <label className="block text-sm font-bold mb-1" htmlFor="login-password">كلمة السر</label>
              <input id="login-password" type="password" autoComplete="current-password"
                required value={loginPass} onChange={(e) => setLoginPass(e.target.value)}
                className="w-full rounded-xl border px-3 py-2.5 mb-4 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }}
                placeholder="كلمة السر" />
              {loginErr && <p className="text-rose-600 font-bold text-sm mb-3">{loginErr}</p>}
              <button type="submit" className="grad-bg w-full text-white font-cairo font-extrabold text-lg rounded-xl py-3 shadow hover:opacity-95 touch-manipulation">
                دخول النظام
              </button>
            </form>
            <p className="text-xs mt-4 leading-6" style={{ color: 'var(--ink-soft)' }}>
              المعلمون: كلمة السر الافتراضية 123456 · المدير: رقمه الوظيفي 10510884 وكلمة سره الخاصة.
            </p>
          </section>
        ) : (
          <>
            {/* بطاقة المستخدم */}
            <section className="card-premium mt-6 p-5 anim-up">
              <div className="flex flex-wrap items-center gap-3">
                <div className="w-14 h-14 rounded-2xl grad-bg text-white flex items-center justify-center font-cairo text-2xl font-black">
                  {user.name.trim().charAt(0)}
                </div>
                <div className="min-w-0">
                  <h2 className="font-cairo text-xl font-extrabold truncate">{user.name}</h2>
                  <p className="text-sm" style={{ color: 'var(--ink-soft)' }}>{user.spec} · الرقم الوظيفي {user.id}</p>
                </div>
                <span className={`ms-auto rounded-full px-3 py-1 text-sm font-bold text-white ${isManager ? 'bg-indigo-600' : user.role === 'deputy' ? 'bg-blue-500' : 'bg-emerald-600'}`}>
                  {isManager ? 'مدير المدرسة' : user.role === 'deputy' ? 'نائب المدير' : 'معلم'}
                </span>
              </div>
            </section>

            {!isManager && (
              /* ---------- واجهة المعلم ---------- */
              <section className="card-premium mt-5 p-5 anim-up">
                <h3 className="font-cairo text-lg font-extrabold flex items-center gap-2 mb-3">
                  <MapPin className="text-blue-600" /> تسجيل الحضور ليوم {date}
                </h3>

                {/* لافتة الحالة الفعّالة للتحقق الجغرافي — تُحدَّث من السحابة كل 3 ثوانٍ */}
                {settings.locationVerificationEnabled ? (
                  <div className="rounded-2xl px-4 py-4 mb-4 bg-blue-600 text-white shadow flex items-start gap-3">
                    <MapPin className="shrink-0 mt-0.5" size={22} />
                    <div className="min-w-0">
                      <p className="font-cairo font-extrabold text-base">التحقق من الموقع مفعّل — يجب أن تكون داخل المدرسة</p>
                      <p className="text-sm opacity-90 mt-0.5">يجب أن تكون ضمن {settings.radiusM} م من المدرسة لتسجيل الحضور.</p>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-2xl px-4 py-4 mb-4 bg-emerald-600 text-white shadow flex items-start gap-3">
                    <CheckCircle2 className="shrink-0 mt-0.5" size={22} />
                    <div className="min-w-0">
                      <p className="font-cairo font-extrabold text-base">التحقق من الموقع معطّل بقرار المدير</p>
                      <p className="text-sm opacity-90 mt-0.5">يمكنك التسجيل من أي مكان — حتى خارج المدرسة، ولن يُطلب موقعك.</p>
                    </div>
                  </div>
                )}

                {/* شريط حالة مزامنة الإعدادات + زر التحديث القسري من السحابة */}
                <div className="flex flex-wrap items-center gap-2 mb-4 text-xs font-bold">
                  <span className="rounded-full px-2.5 py-1 bg-slate-100 text-slate-700 flex items-center gap-1">
                    <ShieldCheck size={13} /> حالة الإعدادات: {settings.locationVerificationEnabled ? 'التحقق مفعّل' : 'التحقق معطّل'} (إصدار {settingsVersionSeen})
                  </span>
                  {settingsSyncedAt && <span className="rounded-full px-2.5 py-1 bg-slate-100 text-slate-700">آخر جلب من السحابة: {settingsSyncedAt}</span>}
                  <button type="button" disabled={settingsRefreshing} onClick={() => void forceRefreshSettings()}
                    className="rounded-full px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white flex items-center gap-1 touch-manipulation">
                    {settingsRefreshing ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />} تحديث الإعدادات من السحابة
                  </button>
                </div>

                <div className={`rounded-xl px-4 py-3 mb-4 text-sm font-bold flex items-start gap-2 ${settings.locationVerificationEnabled ? 'bg-blue-50 text-blue-900 border border-blue-200' : 'bg-emerald-50 text-emerald-900 border border-emerald-300'}`}>
                  {settings.locationVerificationEnabled
                    ? <><MapPin className="shrink-0 mt-0.5 text-blue-700" size={17} /><span>التحقق الجغرافي مفعّل: يجب أن تكون ضمن {settings.radiusM} م من المدرسة لتسجيل الحضور.{settingsSyncedAt && <span className="block text-xs font-normal mt-0.5">آخر تحديث للإعدادات من السحابة: {settingsSyncedAt}</span>}{geoMsg && <span className="block w-full mt-1">{geoMsg}</span>}</span></>
                    : <><CheckCircle2 className="shrink-0 mt-0.5 text-emerald-600" size={17} /><span>التحقق من الموقع الجغرافي معطّل بقرار المدير — يمكنك التسجيل من أي مكان، ولن يُطلب موقعك.{settingsSyncedAt && <span className="block text-xs font-normal mt-0.5">آخر تحديث للإعدادات من السحابة: {settingsSyncedAt}</span>}{geoMsg && <span className="block w-full mt-1">{geoMsg}</span>}</span></>}
                </div>
                <div className="flex flex-wrap items-center gap-2 mb-4 text-xs font-bold">
                  <span className={`rounded-full px-2.5 py-1 flex items-center gap-1 ${isOnline ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                    {isOnline ? <Wifi size={13} /> : <WifiOff size={13} />} حالة الاتصال: {isOnline ? 'متصل' : 'غير متصل'}
                  </span>
                  {lastSync && <span className="rounded-full px-2.5 py-1 bg-slate-100 text-slate-700">آخر مزامنة: {lastSync}</span>}
                  {queue.length > 0 && <span className="rounded-full px-2.5 py-1 bg-amber-100 text-amber-800 flex items-center gap-1"><CloudUpload size={13} /> {queue.length} سجل بانتظار الرفع للسحابة</span>}
                </div>
                {myToday ? (
                  <div className="flex flex-wrap items-center gap-2 mb-4">
                    <span className={`text-white rounded-full px-3 py-1 text-sm font-bold flex items-center gap-1 ${statusColor(myToday.value.status)}`}>
                      {statusIcon(myToday.value.status)} حالتك اليوم: {myToday.value.status}
                    </span>
                    <span className="text-sm" style={{ color: 'var(--ink-soft)' }}>الساعة {myToday.value.time}{myToday.value.distanceM != null ? ` · على بعد ${myToday.value.distanceM} م` : ''}</span>
                    {myPending
                      ? <span className="rounded-full px-2.5 py-1 text-xs font-bold bg-amber-100 text-amber-800 flex items-center gap-1 pulse-dot"><CloudUpload size={13} /> بانتظار المزامنة مع السحابة</span>
                      : <span className="rounded-full px-2.5 py-1 text-xs font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1"><CheckCircle2 size={13} /> محفوظ في السحابة — ظاهر لدى المدير</span>}
                  </div>
                ) : (
                  <p className="text-sm font-bold mb-4" style={{ color: 'var(--ink-soft)' }}>لم تُسجَّل أي حالة لك في هذا التاريخ بعد.</p>
                )}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <button type="button" disabled={!!marking} onClick={() => teacherMark('حضور')} className="btn-quick touch-manipulation bg-emerald-500 hover:bg-emerald-600 disabled:opacity-60 text-white font-cairo font-extrabold rounded-xl py-3 flex items-center justify-center gap-1">
                    {marking === 'حضور' ? <Loader2 size={17} className="animate-spin" /> : <CheckCircle2 size={17} />} حضور
                  </button>
                  <button type="button" disabled={!!marking} onClick={() => teacherMark('غياب')} className="btn-quick touch-manipulation bg-rose-500 hover:bg-rose-600 disabled:opacity-60 text-white font-cairo font-extrabold rounded-xl py-3 flex items-center justify-center gap-1">
                    {marking === 'غياب' ? <Loader2 size={17} className="animate-spin" /> : <XCircle size={17} />} غياب
                  </button>
                  <button type="button" disabled={!!marking} onClick={teacherEndDay} className="btn-quick touch-manipulation bg-slate-600 hover:bg-slate-700 disabled:opacity-60 text-white font-cairo font-extrabold rounded-xl py-3 flex items-center justify-center gap-1">
                    {marking === 'إنهاء دوام' ? <Loader2 size={17} className="animate-spin" /> : <TimerOff size={17} />} إنهاء اليوم
                  </button>
                  <button type="button" disabled={!!marking} onClick={teacherEarlyDeparture} className="btn-quick touch-manipulation bg-teal-500 hover:bg-teal-600 disabled:opacity-60 text-white font-cairo font-extrabold rounded-xl py-3 flex items-center justify-center gap-1">
                    {marking === 'مبكر' ? <Loader2 size={17} className="animate-spin" /> : <DoorOpen size={17} />} مغادرة مبكرة
                  </button>
                </div>
                {marking && <p className="text-sm font-bold mt-3 text-blue-700 flex items-center gap-1"><Loader2 size={15} className="animate-spin" /> جارٍ التسجيل والحفظ في السحابة…</p>}
                <button type="button" onClick={async () => {
                    const fresh = await fetchFreshSettings();
                    if (!getEffectiveLocationEnabled()) { setGeoOk(true); setGeoMsg('التحقق من الموقع الجغرافي معطّل بقرار المدير — يمكنك التسجيل من أي مكان دون فحص موقع'); return; }
                    try { const p = await checkGeo(); setGeoOk(p.d <= fresh.radiusM); setGeoMsg(`موقعك الحالي: أنت على بعد ${p.d} م من المدرسة (الحد ${fresh.radiusM} م)`); }
                    catch (e: any) { setGeoMsg(e.message); }
                  }}
                  className="mt-3 flex items-center gap-1 text-blue-700 font-bold text-sm hover:underline touch-manipulation">
                  <Navigation size={15} /> فحص موقعي الآن
                </button>
                {geoOk && !settings.locationVerificationEnabled && (
                  <span className="inline-flex items-center gap-1 mt-2 ms-2 rounded-full px-2.5 py-1 text-xs font-bold bg-emerald-100 text-emerald-800"><CheckCircle2 size={13} /> التسجيل متاح من أي مكان الآن</span>
                )}
                {geoPos && <p className="text-xs mt-1" style={{ color: 'var(--ink-soft)' }}>الإحداثيات: {geoPos.lat.toFixed(6)} , {geoPos.lng.toFixed(6)}</p>}

                <h4 className="font-cairo font-extrabold mt-6 mb-2">سجلّي الأخير</h4>
                <div className="space-y-2">
                  {records.filter((r) => String(r.value.teacherId) === String(user.id)).slice(-8).reverse().map((r) => (
                    <div key={r.id} className="flex items-center gap-2 rounded-xl border px-3 py-2 text-sm" style={{ borderColor: 'var(--line)' }}>
                      <span className={`text-white rounded-full px-2 py-0.5 text-xs font-bold flex items-center gap-1 ${statusColor(r.value.status)}`}>{statusIcon(r.value.status)} {r.value.status}</span>
                      <span className="font-bold">{r.value.date}</span>
                      <span style={{ color: 'var(--ink-soft)' }}>{r.value.time}{r.value.distanceM != null ? ` · ${r.value.distanceM} م` : ''}{r.id.startsWith('tmp-') ? ' · بانتظار المزامنة' : ''}</span>
                    </div>
                  ))}
                  {records.filter((r) => String(r.value.teacherId) === String(user.id)).length === 0 &&
                    <p className="text-sm" style={{ color: 'var(--ink-soft)' }}>لا توجد سجلات بعد.</p>}
                </div>
              </section>
            )}

            {isManager && (
              /* ---------- واجهة المدير ---------- */
              <>
                <section className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
                  {[
                    { label: 'إجمالي المعلمين', val: dayStats.total, cls: 'text-blue-700' },
                    { label: 'حضور اليوم', val: dayStats.present, cls: 'text-emerald-600' },
                    { label: 'غياب اليوم', val: dayStats.absent, cls: 'text-rose-600' },
                    { label: 'تم تسجيلهم', val: dayStats.marked, cls: 'text-indigo-600' },
                  ].map((c) => (
                    <div key={c.label} className="card-premium p-4 text-center anim-up">
                      <div className={`font-cairo text-3xl font-black ${c.cls}`}>{c.val}</div>
                      <div className="text-sm font-bold" style={{ color: 'var(--ink-soft)' }}>{c.label}</div>
                    </div>
                  ))}
                </section>

                <div className="flex flex-wrap gap-2 mt-5">
                  {([
                    { k: 'quick', label: 'الجدول السريع', icon: <ClipboardList size={16} /> },
                    { k: 'report', label: 'التقارير والتصدير', icon: <FileBarChart size={16} /> },
                    { k: 'staff', label: 'إدارة المعلمين', icon: <Users size={16} /> },
                    { k: 'settings', label: 'الإعدادات والموقع', icon: <SettingsIcon size={16} /> },
                  ] as const).map((t) => (
                    <button type="button" key={t.k} onClick={() => setTab(t.k)}
                      className={`flex items-center gap-1.5 rounded-full px-4 py-2 font-cairo font-extrabold text-sm touch-manipulation ${tab === t.k ? 'grad-bg text-white shadow' : 'bg-white border'}`}
                      style={tab === t.k ? {} : { borderColor: 'var(--line)', color: 'var(--ink)' }}>
                      {t.icon} {t.label}
                    </button>
                  ))}
                  <button type="button" onClick={() => { void syncCloud().then(() => showToast('تم تحديث البيانات من السحابة')); }}
                    className="flex items-center gap-1.5 rounded-full px-4 py-2 font-cairo font-extrabold text-sm bg-white border touch-manipulation" style={{ borderColor: 'var(--line)' }}>
                    <RefreshCw size={16} /> تحديث
                  </button>
                </div>

                {tab === 'quick' && (
                  <section className="card-premium mt-4 p-4 anim-up">
                    <h3 className="font-cairo text-lg font-extrabold mb-1">حالة جميع المعلمين — {date}</h3>
                    <p className="text-xs mb-3" style={{ color: 'var(--ink-soft)' }}>اضغط أي زر لتسجيل الحالة فوراً — ينعكس التسجيل هنا مباشرة ويُحفظ سحابياً بالخلفية، وتسجيلات المعلمين من هواتفهم تظهر هنا تلقائياً خلال ثوانٍ. {TEACHERS_ONLY.length} معلماً.</p>
                    <div style={{ overflow: 'visible' }}>
                      {TEACHERS_ONLY.map((t, idx) => {
                        const rec = findRec(t.id, date);
                        return (
                          <div key={`mgr-row-${String(t.id)}-${idx}`} className="border-b py-2.5" style={{ borderColor: 'var(--line)' }}>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-bold text-sm min-w-0 flex-1">
                                <span style={{ color: 'var(--ink-soft)' }}>{idx + 1}. </span>{t.name}
                                <span className="block text-xs font-normal" style={{ color: 'var(--ink-soft)' }}>{t.id} · {t.spec}</span>
                              </span>
                              {rec
                                ? <span className={`text-white rounded-full px-2.5 py-0.5 text-xs font-bold flex items-center gap-1 ${statusColor(rec.value.status)}`}>{statusIcon(rec.value.status)} {rec.value.status} · {rec.value.time}{rec.id.startsWith('tmp-') ? ' · يُزامَن' : ''}</span>
                                : <span className="rounded-full px-2.5 py-0.5 text-xs font-bold bg-slate-200 text-slate-600">غير مسجل</span>}
                            </div>
                            <div className="flex flex-wrap items-center gap-1.5 mt-2">
                              {STATUSES.map((s) => (
                                <button type="button" key={s} onClick={() => handleManagerSetStatus(String(t.id), s)}
                                  className={`btn-quick touch-manipulation text-white rounded-lg px-3 py-1.5 text-xs font-extrabold flex items-center gap-1 ${statusColor(s)} ${rec?.value.status === s ? 'ring-2 ring-offset-1 ring-slate-700' : 'opacity-90 hover:opacity-100'}`}>
                                  {statusIcon(s)} {s}
                                </button>
                              ))}
                              <select className="native-select rounded-lg border px-2 py-1.5 text-xs font-bold bg-white text-slate-700 touch-manipulation"
                                style={{ borderColor: 'var(--line)' }}
                                value={rec?.value.status || ''}
                                onChange={(e) => { if (e.target.value) handleManagerSetStatus(String(t.id), e.target.value); }}>
                                <option value="">اختيار سريع…</option>
                                {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                                <option value="إنهاء دوام">إنهاء دوام</option>
                              </select>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </section>
                )}

                {tab === 'report' && (
                  <section className="card-premium mt-4 p-5 anim-up">
                    <h3 className="font-cairo text-lg font-extrabold mb-3">تقرير فترة مخصص (من شهر إلى شهر)</h3>
                    <div className="grid sm:grid-cols-3 gap-3 mb-4">
                      <div>
                        <label className="block text-sm font-bold mb-1">المعلم</label>
                        <select className="native-select w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }}
                          value={repTeacher} onChange={(e) => setRepTeacher(e.target.value)}>
                          <option value="ALL">جميع المعلمين</option>
                          {TEACHERS_ONLY.map((t) => <option key={t.id} value={String(t.id)}>{t.name}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-bold mb-1">من شهر</label>
                        <input type="month" value={repFrom} onChange={(e) => setRepFrom(e.target.value)} className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                      </div>
                      <div>
                        <label className="block text-sm font-bold mb-1">إلى شهر</label>
                        <input type="month" value={repTo} onChange={(e) => setRepTo(e.target.value)} className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-4">
                      <button type="button" onClick={exportCSV} className="flex items-center gap-1 bg-emerald-600 text-white rounded-xl px-4 py-2 font-bold text-sm touch-manipulation"><Download size={15} /> تصدير CSV</button>
                      <button type="button" onClick={() => exportExcelHTML('xls')} className="flex items-center gap-1 bg-blue-600 text-white rounded-xl px-4 py-2 font-bold text-sm touch-manipulation"><Download size={15} /> تصدير Excel</button>
                      <button type="button" onClick={() => exportExcelHTML('html')} className="flex items-center gap-1 bg-indigo-600 text-white rounded-xl px-4 py-2 font-bold text-sm touch-manipulation"><Download size={15} /> تصدير HTML</button>
                    </div>
                    <p className="text-sm font-bold mb-2">عدد السجلات في الفترة: {reportRows.length}</p>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm min-w-[560px]">
                        <thead>
                          <tr className="text-right" style={{ color: 'var(--ink-soft)' }}>
                            <th className="py-2 px-2">المعلم</th><th className="px-2">حضور</th><th className="px-2">غياب</th>
                            <th className="px-2">مرضية</th><th className="px-2">طارئة</th><th className="px-2">تأخر</th><th className="px-2">مبكر</th>
                          </tr>
                        </thead>
                        <tbody>
                          {reportSummary.map(([tid, c]) => (
                            <tr key={tid} className="border-t" style={{ borderColor: 'var(--line)' }}>
                              <td className="py-2 px-2 font-bold">{(c as any).name}</td>
                              <td className="px-2">{(c as any)['حضور'] || 0}</td><td className="px-2">{(c as any)['غياب'] || 0}</td>
                              <td className="px-2">{(c as any)['مرضية'] || 0}</td><td className="px-2">{(c as any)['طارئة'] || 0}</td>
                              <td className="px-2">{(c as any)['تأخر'] || 0}</td><td className="px-2">{(c as any)['مبكر'] || 0}</td>
                            </tr>
                          ))}
                          {reportSummary.length === 0 && <tr><td colSpan={7} className="py-4 text-center" style={{ color: 'var(--ink-soft)' }}>لا توجد سجلات في هذه الفترة.</td></tr>}
                        </tbody>
                      </table>
                    </div>
                  </section>
                )}

                {tab === 'staff' && (
                  <section className="card-premium mt-4 p-5 anim-up">
                    <div ref={staffFormRef}>
                      <h3 className="font-cairo text-lg font-extrabold mb-3 flex items-center gap-2">
                        {editingId ? <Pencil className="text-amber-600" /> : <UserPlus className="text-blue-600" />}
                        {editingId ? `تعديل بيانات: ${staff.find((s) => String(s.id) === String(editingId))?.name || ''}` : 'إضافة معلم جديد'}
                      </h3>
                      {editingId && (
                        <div className="rounded-xl bg-amber-100 border border-amber-300 text-amber-900 px-3 py-2.5 mb-3 flex flex-wrap items-center gap-2 text-sm font-bold">
                          <Pencil size={15} className="shrink-0" />
                          <span>وضع التعديل مفعّل — عدّل الحقول أدناه ثم اضغط «حفظ التعديلات».</span>
                          <button type="button" onClick={cancelEdit} className="ms-auto bg-white/80 hover:bg-white border border-amber-300 rounded-lg px-3 py-1 text-xs font-extrabold touch-manipulation">إلغاء التعديل</button>
                        </div>
                      )}
                      <div className="grid sm:grid-cols-2 gap-3 mb-3">
                        <div>
                          <label className="block text-sm font-bold mb-1">الرقم الوظيفي</label>
                          <input value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value })} placeholder="الرقم الوظيفي" className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                        </div>
                        <div>
                          <label className="block text-sm font-bold mb-1">الاسم الكامل</label>
                          <input ref={staffNameRef} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="الاسم الكامل" className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                        </div>
                        <div>
                          <label className="block text-sm font-bold mb-1">التخصص / الوظيفة</label>
                          <input value={form.spec} onChange={(e) => setForm({ ...form, spec: e.target.value })} placeholder="التخصص / الوظيفة" className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                        </div>
                        <div>
                          <label className="block text-sm font-bold mb-1">كلمة المرور</label>
                          <input value={form.pass} onChange={(e) => setForm({ ...form, pass: e.target.value })} placeholder="كلمة المرور" className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button type="button" onClick={saveStaffMember} className="grad-bg text-white rounded-xl px-5 py-2.5 font-cairo font-extrabold flex items-center gap-1 touch-manipulation"><Save size={16} /> {editingId ? 'حفظ التعديلات' : 'إضافة المعلم'}</button>
                        {editingId && (
                          <button type="button" onClick={cancelEdit} className="bg-white border rounded-xl px-5 py-2.5 font-cairo font-extrabold touch-manipulation" style={{ borderColor: 'var(--line)' }}>إلغاء</button>
                        )}
                      </div>
                    </div>
                    {seedBusy && <p className="text-xs mt-3 font-bold text-blue-700 flex items-center gap-1"><Loader2 size={13} className="animate-spin" /> جارٍ نشر قائمة المعلمين الـ31 في السحابة لأول مرة…</p>}
                    {seedResult && seedResult.remaining > 0 && (
                      <div className="mt-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 px-3 py-2 text-xs font-bold flex items-start gap-2">
                        <CloudOff size={15} className="shrink-0 mt-0.5" />
                        <span>نشر القائمة السحابية: حُفظ {seedResult.saved} وبقي {seedResult.remaining}{seedResult.error ? ` — السبب: ${seedResult.error}` : ''}. سجلات الحضور لا تتأثر، وستكتمل القائمة تلقائياً عند توفر الاتصال.</span>
                      </div>
                    )}
                    {seedResult && seedResult.remaining === 0 && seedResult.saved > 0 && (
                      <p className="text-xs mt-3 font-bold text-emerald-700 flex items-center gap-1"><CheckCircle2 size={13} /> قائمة المعلمين منشورة في السحابة ({seedResult.saved} معلماً) — أي هاتف جديد سيستلمها كاملة.</p>
                    )}
                    <p className="text-xs mt-4 mb-1 font-bold" style={{ color: 'var(--ink-soft)' }}>كشف الموظفين ({staff.length}) — اضغط «تعديل» بجانب أي اسم لتعديل بياناته في النموذج أعلاه.</p>
                    <div className="mt-2 space-y-2">
                      {staff.map((s, i) => {
                        const isEditingRow = editingId !== null && String(s.id) === String(editingId);
                        return (
                          <div key={`${s.id}-${i}`} className={`flex flex-wrap items-center gap-2 rounded-xl border px-3 py-2 text-sm ${isEditingRow ? 'ring-2 ring-amber-400 bg-amber-50' : ''}`} style={{ borderColor: 'var(--line)' }}>
                            <span className="font-bold flex-1 min-w-[180px]">
                              <span style={{ color: 'var(--ink-soft)' }}>{i + 1}. </span>{s.name}
                              {isEditingRow && <span className="ms-2 rounded-full bg-amber-400 text-amber-950 px-2 py-0.5 text-[11px] font-extrabold">قيد التعديل الآن</span>}
                              <span className="block text-xs font-normal" style={{ color: 'var(--ink-soft)' }}>{s.id} · {s.spec}</span>
                            </span>
                            <button type="button" onClick={() => startEditTeacher(s)} className="btn-quick touch-manipulation flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-3 py-1.5 font-bold text-xs shadow-sm"><Pencil size={13} /> تعديل</button>
                            {String(s.id) !== MANAGER_ID && (
                              <button type="button" onClick={() => { if (isEditingRow) cancelEdit(); deleteStaffMember(s.id); }} className="btn-quick touch-manipulation flex items-center gap-1 bg-rose-100 text-rose-700 rounded-lg px-3 py-1.5 font-bold text-xs"><Trash2 size={13} /> حذف</button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </section>
                )}

                {tab === 'settings' && (
                  <section className="card-premium mt-4 p-5 anim-up">
                    <h3 className="font-cairo text-lg font-extrabold mb-4">إعدادات التحقق الجغرافي</h3>
                    <div className="flex items-center justify-between gap-3 rounded-2xl border px-4 py-4 mb-4" style={{ borderColor: 'var(--line)' }}>
                      <div>
                        <p className="font-cairo font-extrabold flex items-center gap-2">
                          {settings.locationVerificationEnabled ? <ShieldCheck className="text-emerald-600" size={19} /> : <ShieldOff className="text-amber-600" size={19} />}
                          التحقق من الموقع الجغرافي للجميع
                        </p>
                        <p className="text-sm mt-1" style={{ color: 'var(--ink-soft)' }}>
                          {settings.locationVerificationEnabled
                            ? 'مفعّل: لا يستطيع المعلم التسجيل إلا داخل نطاق المدرسة.'
                            : 'معطّل: يمكن للمعلمين التسجيل من أي مكان بقرار المدير.'}
                        </p>
                        <p className="text-xs mt-1" style={{ color: 'var(--ink-soft)' }}>
                          إصدار الإعدادات الحالي: {settingsVersionSeen}{settingsSyncedAt ? ` · آخر مزامنة: ${settingsSyncedAt}` : ''}
                        </p>
                      </div>
                      <button type="button" role="switch" aria-checked={settings.locationVerificationEnabled}
                        onClick={() => void toggleLocationVerification()}
                        className={`relative w-16 h-9 rounded-full transition-colors shrink-0 touch-manipulation ${settings.locationVerificationEnabled ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                        <span className={`absolute top-1 w-7 h-7 bg-white rounded-full shadow transition-all ${settings.locationVerificationEnabled ? 'right-1' : 'right-8'}`} />
                      </button>
                    </div>
                    <div className="grid sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-sm font-bold mb-1">خط عرض المدرسة</label>
                        <input type="number" step="0.000001" value={settings.schoolLat} onChange={(e) => setSettings({ ...settings, schoolLat: parseFloat(e.target.value) || 0 })} className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                      </div>
                      <div>
                        <label className="block text-sm font-bold mb-1">خط طول المدرسة</label>
                        <input type="number" step="0.000001" value={settings.schoolLng} onChange={(e) => setSettings({ ...settings, schoolLng: parseFloat(e.target.value) || 0 })} className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                      </div>
                      <div>
                        <label className="block text-sm font-bold mb-1">نصف قطر النطاق (متر)</label>
                        <input type="number" value={settings.radiusM} onChange={(e) => setSettings({ ...settings, radiusM: parseInt(e.target.value) || 0 })} className="w-full rounded-xl border px-3 py-2 bg-white text-slate-800 touch-manipulation" style={{ borderColor: 'var(--line)' }} />
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-4">
                      <button type="button" onClick={() => void saveSettings(settings)} className="grad-bg text-white rounded-xl px-5 py-2.5 font-cairo font-extrabold flex items-center gap-1 touch-manipulation"><Save size={16} /> حفظ الإعدادات</button>
                      <button type="button" onClick={async () => { try { const p = await checkGeo(); void saveSettings({ ...settings, schoolLat: p.lat, schoolLng: p.lng }); showToast('تم اعتماد موقعك الحالي موقعاً للمدرسة'); } catch (e: any) { showToast(e.message, false); } }}
                        className="bg-white border rounded-xl px-5 py-2.5 font-cairo font-extrabold flex items-center gap-1 touch-manipulation" style={{ borderColor: 'var(--line)' }}>
                        <Navigation size={16} /> اعتماد موقعي الحالي موقعاً للمدرسة
                      </button>
                    </div>
                    <p className="text-xs mt-4 leading-6" style={{ color: 'var(--ink-soft)' }}>
                      ملاحظة: المدير معفى من التحقق الجغرافي دائماً. تُحفظ هذه الإعدادات في قاعدة البيانات السحابية مع رقم إصدار وطابع زمني، وتنعكس على جميع الأجهزة خلال 3 ثوانٍ.
                    </p>
                  </section>
                )}
              </>
            )}
          </>
        )}

        <footer className="text-center mt-10 pb-2">
          <p style={{ fontSize: 10, color: 'var(--ink-soft)' }}>مدير المدرسة لؤي تيسير نمر الخطيب</p>
        </footer>
      </main>

      {toast && (
        <div className={`fixed bottom-5 right-1/2 translate-x-1/2 sm:right-5 sm:translate-x-0 z-50 max-w-[92vw] rounded-2xl px-4 py-3 text-white font-bold shadow-2xl flex items-center gap-2 ${toast.ok ? 'bg-emerald-600' : 'bg-rose-600'}`}>
          {toast.ok ? <CheckCircle2 size={18} /> : <XCircle size={18} />} {toast.msg}
        </div>
      )}
    </div>
  );
}
